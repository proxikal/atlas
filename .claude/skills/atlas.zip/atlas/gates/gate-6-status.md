# GATE 6: Update Status (Structured Development Only)

**Condition:** Structured development workflow, all gates passed

---

## Action

1. Update STATUS.md or phase tracking
2. Mark work complete
3. Note next steps if applicable
4. Record completion date

---

**BLOCKING:** Required for structured development only.

**Next:** Done
